n = int(input("Insira um número: "))
divs = 0

for i in range(1, n):
    if n % i == 0:
        divs += i
if divs == n:
    print("É perfeito")
else:
    print("Não é perfeito")
