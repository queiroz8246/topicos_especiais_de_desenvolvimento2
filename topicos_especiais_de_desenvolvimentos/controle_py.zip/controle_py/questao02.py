n = int(input("Informe um número: "))
primo = True

for i in range(2, n):
    if n % 2 == 0:
        continue
    for j in range(2, n):
        if i % j == 0:
            primo = False
            break

if n == 1:
    print("Não é primo")

elif primo:
    print("É primo")
else:
    print("Não é primo")