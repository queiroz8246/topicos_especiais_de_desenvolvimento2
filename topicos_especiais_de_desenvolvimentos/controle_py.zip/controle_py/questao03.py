n1 = int(input("insira um número: "))
n2 = int(input("insira outro número: "))

r = (n1 ** 2) + (n2 ** 2)

print(f"resultado: {r}")
