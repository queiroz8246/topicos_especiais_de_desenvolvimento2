def contar_Pares(numero):
    for i in range(0, numero + 1):
        if i % 2 == 0:
            print(i, end=" ")
n = int(input("Insira um número: "))
contar_Pares(n)