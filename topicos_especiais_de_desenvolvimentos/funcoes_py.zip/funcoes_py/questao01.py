def calcular_Media(nota1 = 0, nota2 = 0, nota3 = 0):
    media = (nota1 + nota2 + nota3) / 3
    return media

nota1 = float(input("Insira sua 1º nota: "))
nota2 = float(input("Insira sua 2º nota: "))
nota3 = float(input("Insira sua 3º nota: "))
print(f"media: {calcular_Media(nota1, nota2, nota3):.1f}")
