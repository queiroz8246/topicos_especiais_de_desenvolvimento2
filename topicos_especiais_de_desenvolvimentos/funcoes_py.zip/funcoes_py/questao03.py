def calculadora(n1, op, n2):
    retorno = 0
    if op == "+":
        retorno = n1 + n2
    elif op == "-":
        retorno = n1 - n2
    elif op == "/":
        retorno = n1 / n2
    elif op == "*":
        retorno = n1 * n2
    else:
        retorno = "operacão"
    return retorno

n1 = int(input("Insira um número: "))
op = (input("Insira a operação: "))
n2 = int(input("Insira outo número: "))

print(f"resultado: {calculadora(n1, op, n2)}")