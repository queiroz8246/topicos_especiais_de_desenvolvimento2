def estatisticas(*args):
    variavel = args
    maior = 0
    menor = 0
    soma  = 0
    media = 0
    for i in variavel:
        if i > maior: maior = i
        if i < menor: menor = i
        soma += i
    media = soma / len(variavel)
    return maior, menor, soma, media

resultado = estatisticas(7, 0, -1, 8, 20, 40, 100, 60, 1)

print(f"maior: {resultado[0]}\nmenor: {resultado[1]}\nsoma: {resultado[2]}\nmedia: {resultado[3]:.2f}")