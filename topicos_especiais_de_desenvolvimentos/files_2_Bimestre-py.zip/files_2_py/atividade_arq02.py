from datetime import date

try:
    with open("diario.txt", "r") as arq:
        pass
except FileNotFoundError:
    with open("diario.txt", "w") as arq:
        arq.write("")

variavel = 0

with open("diario.txt", "a") as arq:
    variavel = arq.write("Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque soluta eligendi nam? Ad non, minima laudantium sunt mollitia sit ducimus, vero velit adipisci deleniti, reiciendis molestiae alias iure ab totam!")

with open("diario.txt", "r") as arq:
    variavel = arq.read()
    variavel = variavel.split(" ")
    print(f"o número de palavras é: {len(variavel)}")

with open("diario.txt", "a") as arq:
    variavel = arq.write(f"{date.today()}{len(variavel)}")


