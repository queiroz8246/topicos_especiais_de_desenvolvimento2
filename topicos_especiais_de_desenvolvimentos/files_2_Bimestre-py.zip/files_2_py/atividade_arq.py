import os
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

try:
    with open("inventario.txt", "r") as arq:
        pass
except FileNotFoundError:
    with open("inventario.txt", "w") as arq:
        arq.write("")


def armazenar(invent):
    while True:
        clear_screen()
        
        produto = input('Informe o nome do produto: ')
        quantidade = input('Informe a quantidade do produto: ')
        clear_screen()
        outroProduto = input('Voce deseja adicionar outro produto? (s,n): ').lower()
        with open('inventario.txt','a') as arquivo:
            arquivo.write(f"{produto};{quantidade}|")

        invent.append([produto, quantidade])

        if(outroProduto == 'n'):
            return invent

def Ler():
    invent = []
    produto = 0
    quant = 0
    with open("inventario.txt", "r") as arq:
        line = arq.read()
        line = line.split("|")
        for i in range(len(line) - 1):
            a = line[i].split(";")
            produto = a[0]
            quant = a[1]
            print(f"Produto: {produto}")
            print(f"Quantidade: {quant} \n")
            invent.append([produto, quant])
    input()
    return invent

def remover(invent):
    remover = False
    index = 0
    print(invent)
    variante = input("qual produto deseja retirar: ")
    for i in range(len(invent) - 1):
        if variante in invent[i]:
            index = i
            remover = True
            break

    if remover:
        print("removendo")
        with open("inventario.txt", "w") as arq:
            arq.write("")
        del invent[index]
        new_vp = invent
        for j in range(len(invent)):
            with open('inventario.txt','a') as arquivo:
                arquivo.write(f"{new_vp[j][0]};{new_vp[j][1]}|")
    input()
    Ler()   
    print("remoção completa")
    input()

def init():
    all_inventory = []
    while True:
        clear_screen()
        print("1 = Adicionar_produto")
        print("2 = Listar_inventario")
        print("3 = Remover_produto")
        print("4 = sair")
        escolha = input()

        if escolha == "1":
            all_inventory = armazenar(all_inventory)
        elif escolha == "2":
            all_inventory = Ler()
        elif escolha == "3":
            all_inventory = remover(all_inventory)
        else:
            clear_screen()
            break

init()