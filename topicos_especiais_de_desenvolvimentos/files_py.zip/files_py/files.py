import os
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


try:
    with open("agenda.txt", "r") as arq:
        load = arq.read()

except FileNotFoundError:
    with open("agenda.txt", "w") as memory:
        memory.write("")


def init():
    paciente = {
            "nome":  0,
            "idade": 0,
            "data":  0,
            "hora":  0
        }
    clear_screen()
    print("{:=^100}".format("Sistema de Agendamento - Psicóloga"))
    print("1. Agendar novo atendimento: ")
    print("2. Mostrar atendimentos agendados: ")
    print("3. Sair: ")
    print("=" * 100)
    escolha = input()
    clear_screen()

    if escolha == "1":
        print("{:=^100}".format("Formulário de Agendamento - Psicóloga"))

        nome = input("Digite o nome do paciente: ")
        idade = input("Digite a idade do paciente: ")
        data = input("Digite a data do atendimento (dd/mm/aaaa): ")
        hora = input("Digite o horário do atendimento (hh:mm): ")

        paciente['nome'] = nome
        paciente['idade'] = idade + " anos"
        paciente['data'] = data
        paciente["hora"] = hora

        with open("agenda.txt", "a") as memory:
            memory.write(f"{paciente['nome']};{paciente['idade']};{paciente['data']};{paciente["hora"]}|")
        init()

    elif escolha == "2":
        print("{:=^100}\n".format("Agendamentos - Psicóloga"))
        with open("agenda.txt", "r") as arq:
            load = arq.read()
            load = load.split("|")
            for i in range(0, len(load) - 1):
                aux = load[i].split(";")
                paciente["nome"] = aux[0]
                paciente["idade"] = aux[1]
                paciente["data"] = aux[2]
                paciente["hora"] = aux[3]
                print("{:-^20}".format(f"paciente: {paciente['nome']}"))
                print(f"Nome: {paciente['nome']}")
                print(f"Idade: {paciente['idade']}")
                print(f"Data: {paciente['data']}")
                print(f"Hora: {paciente['hora']}")
                print("\n \n")
        input()
        init()


            


init()