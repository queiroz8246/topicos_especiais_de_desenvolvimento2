a = input("Insira algo: ")
a = a[::-1]
print(a)