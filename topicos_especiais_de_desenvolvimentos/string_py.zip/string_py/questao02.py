a = input("Insira algo: ")
a = a.replace("banana", "Maçã")
print(a)