a = input("Insira algo: ")
a = a.replace(" ", "A")
print(a)