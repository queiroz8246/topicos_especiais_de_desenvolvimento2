num = 4

for i in range(0, num):
    for j in range(0, i):
        print(i, end=' ')
print("")