a = 1
b = 1
c = 0

print(f"{a} {b}", end=" ")
for i in range(0, 8):
    c = a + b
    print(c, end=" ")
    b = a
    a = c