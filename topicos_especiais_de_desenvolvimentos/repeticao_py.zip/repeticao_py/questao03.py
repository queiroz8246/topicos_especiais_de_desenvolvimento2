n = int(input("digite um numero: "))

raiz = n / 2

precisao = 0.0001

while abs(raiz * raiz - n) > precisao:
    raiz =  (raiz + n / raiz) / 2

print(f"A raiz quadrada de {raiz:.4f}")