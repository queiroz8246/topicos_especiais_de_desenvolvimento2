soma = 0
num = ((1, 2), (3, 4), (5, 6))
for i in num:
    soma += i[1]
print('soma:',soma)
        
