entrada = ["PYTHON", "java", "JAVASCRIPT", "C", "RUBY"]

for i in range(len(entrada)):
    if len(entrada[i]) > 4:
        if entrada[i].isupper():
            print(entrada[i], end=" ")
