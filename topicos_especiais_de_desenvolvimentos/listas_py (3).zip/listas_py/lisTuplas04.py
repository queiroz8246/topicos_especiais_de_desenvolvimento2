entrada = [(1, 2), (3, 4), (5, 6)]
saida = []

for i in entrada:
    saida.append([i[0], i[1]])

for i in range(len(saida)):
    saida[i][1] += 10

print(saida)