numero_primo = 0
div = 0

for i in range(1, 50):
    for j in range(1, 50):
        if j > i:
            break

        elif i % j == 0:
            div += 1

    if numero_primo == 10:
        break

    elif div == 2:
        print(i, end=" ")
        numero_primo += 1
    
    div = 0