while(True):
    nome = input("Insira o nome do aluno: ")
    idade = int(input("Insira a idade do aluno: "))
    altura = float(input("Insira a altura do aluno: "))
    estudante = input("estudante? s/n: ").lower()
    if estudante == "s": estudante = True
    else: estudante = False
    hobbies = []
    while(True):
        hobbies.append(input("Insira um hobbie: "))
        finish1 = input("").lower()
        if finish1 == "n": break

    finish2 = input("").lower()
    if finish2 == "n": break

