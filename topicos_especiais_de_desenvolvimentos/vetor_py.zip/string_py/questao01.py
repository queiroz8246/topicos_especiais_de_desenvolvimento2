nome = input("insira o seu nome: ")
notas = []
maior = 6.8
menor = 6.9

for i in range(0, 3):
    notas.append(float(input(f"Insira sua {i + 1}º nota: ")))
    if notas[i] > maior: maior = notas[i]
    if notas[i] < menor: menor = notas[i]

print(f"Aluno: {nome}")
print(f"Maior nota: {maior}")
print(f"Menor nota: {menor}")

