a = input("Insira algo: ")
b = input("Insira alguma letra: ")
a = a.count(b)
print(f"A letra a aparece {a} vezes")