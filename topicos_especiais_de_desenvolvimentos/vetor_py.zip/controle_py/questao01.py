n1 = int(input("Informe um número: "))
n2 = int(input("Informe outro número: "))
n3 = int(input("Informe mais um número: "))

c1 = 2 * n1 * n2 / 2
c2 = 3 * n1 + n3
c3 = n3 ** 3

print("")
print(f"O produto do dobro do primeiro com a metade do segundo é: {c1}")
print(f"A soma do triplo do primeiro com o terceiro é: {c2}")
print(f"O terceiro elevado ao cubo é: {c3}")
