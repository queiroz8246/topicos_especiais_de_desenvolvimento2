soma = 0
num = [1,2,3,4,5,6,7]
for i in num:
    if i % 2 == 0:
        soma += i
print('soma:',soma)
        
