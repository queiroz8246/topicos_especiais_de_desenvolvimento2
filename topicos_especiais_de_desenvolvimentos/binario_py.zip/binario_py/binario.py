byte = input("Insira um byte de código binario: ")
decimal = 0
byte = byte[::-1]
for i in range(len(byte)):
    if byte[i] == "1":
        decimal += 2 ** i
print(decimal)
